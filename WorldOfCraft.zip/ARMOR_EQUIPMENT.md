# Armor equipment assets (cleannrooster, free use)

Worn on body via minecraft:equippable.asset_id / EquippableComponent#setModel:
- worldofcraft:runefrost  → poor / common
- worldofcraft:runegleam  → uncommon / rare / heirloom
- worldofcraft:runeblaze  → epic / legendary / mythic

Inventory icons use CMD family bases 2000/2100/2200/2300 + rarity.
