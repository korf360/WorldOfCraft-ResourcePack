# Armor equipment assets (cleannrooster, free use)

Worn on body via minecraft:equippable.asset_id / EquippableComponent#setModel:

## Gear rarity looks
- worldofcraft:runefrost  → poor / common
- worldofcraft:runegleam  → uncommon / rare / heirloom
- worldofcraft:runeblaze  → epic / legendary / mythic

## Vanity / cosmetics sets
- worldofcraft:temple_guardian  — holy plate (paladin)
- worldofcraft:bastion_guardian — crimson dark plate (tank)
- worldofcraft:end_city_guardian — void plate (endgame)
- worldofcraft:magus — sapphire cloth (caster)
- worldofcraft:idyl_cloth
- worldofcraft:idyl_leather
- worldofcraft:idyl_studded
- worldofcraft:idyl_chain
- worldofcraft:idyl_plate
- worldofcraft:flare_clothes
- worldofcraft:flare_robes
- worldofcraft:flare_leather
- worldofcraft:flare_chain
- worldofcraft:flare_plate
- worldofcraft:ivory_steel
- worldofcraft:ivory_bronze
- worldofcraft:ivory_magma
- worldofcraft:ivory_royal
- worldofcraft:ivory_nature
- worldofcraft:ivory_frost
- worldofcraft:ivory_paladin
- worldofcraft:ivory_dark
- worldofcraft:ivory_shadow
- worldofcraft:frigid

## Profession craft looks (smith / tailor)
- worldofcraft:craft_smith — blacksmith Common→Rare
- worldofcraft:craft_nemesis — blacksmith Epic (Nemesis)
- worldofcraft:craft_sovereign — blacksmith Legendary (Sovereign, skill 85+)
- worldofcraft:craft_tailor — tailor Common→Rare
- worldofcraft:craft_shadowthread — tailor Epic (Shadowthread)
- worldofcraft:craft_starweave — tailor Legendary (Starweave, skill 85+)

Inventory icons use CMD family bases 2000/2100/2200/2300 + rarity (rune sets).
Preview: /woc admin previewarmor <set|all>
Credits: resourcepack-src/free-armor/CREDITS.txt
