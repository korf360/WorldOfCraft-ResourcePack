# WorldOfCraft CustomModelData map

Generic gear: CMD = family_base + rarity_ordinal (POOR=0 … HEIRLOOM=7)

## sword (base 1000)
- 1000 poor → dagger
- 1001 common → sword_common
- 1002 uncommon → sword_uncommon
- 1003 rare → sword_rare
- 1004 epic → sword_epic
- 1005 legendary → sword_legendary
- 1006 mythic → sword_mythic
- 1007 heirloom → peachwood

## axe (base 1100)
- 1100 poor → axe_copper
- 1101 common → axe_copper
- 1102 uncommon → axe_viking
- 1103 rare → axe_viking
- 1104 epic → axe_double
- 1105 legendary → axe_double
- 1106 mythic → axe_double
- 1107 heirloom → axe_viking

## hoe (base 1200)
- 1200 poor → crux
- 1201 common → crux
- 1202 uncommon → dagger
- 1203 rare → dao
- 1204 epic → dao
- 1205 legendary → sword_katana
- 1206 mythic → sword_mythic
- 1207 heirloom → crux

## bow (base 1300)
- 1300 poor → bow_a
- 1301 common → bow_a
- 1302 uncommon → bow_a
- 1303 rare → bow_b
- 1304 epic → bow_b
- 1305 legendary → bow_b
- 1306 mythic → bow_b
- 1307 heirloom → bow_a

## crossbow (base 1400)
- 1400 poor → bow_a
- 1401 common → bow_a
- 1402 uncommon → bow_b
- 1403 rare → bow_b
- 1404 epic → bow_b
- 1405 legendary → bow_b
- 1406 mythic → bow_b
- 1407 heirloom → bow_a

## trident (base 1500)
- 1500 poor → sword_rare
- 1501 common → sword_uncommon
- 1502 uncommon → sword_rare
- 1503 rare → sword_epic
- 1504 epic → sword_legendary
- 1505 legendary → sword_mythic
- 1506 mythic → sword_katana
- 1507 heirloom → peachwood

## mace (base 1600)
- 1600 poor → mace_plain
- 1601 common → mace_plain
- 1602 uncommon → mace_plain
- 1603 rare → mace_fancy
- 1604 epic → hammer
- 1605 legendary → hammer_gold
- 1606 mythic → hammer_gold
- 1607 heirloom → mace_fancy

## wand (base 1700)
- 1700 poor → wand_basic
- 1701 common → wand_basic
- 1702 uncommon → wand_basic
- 1703 rare → wand_wizard
- 1704 epic → wand_wizard
- 1705 legendary → wand_necro
- 1706 mythic → wand_necro
- 1707 heirloom → wand_wizard

## shield (base 1800)
- 1800 poor → shield_small
- 1801 common → shield_small
- 1802 uncommon → shield_a
- 1803 rare → shield_a
- 1804 epic → shield_b
- 1805 legendary → shield_b
- 1806 mythic → shield_b
- 1807 heirloom → shield_a

## helmet (base 2000)
- 2000 poor → hat_explorer
- 2001 common → hat_explorer
- 2002 uncommon → hat_explorer
- 2003 rare → hat_wizard
- 2004 epic → hat_wizard
- 2005 legendary → hat_wizard
- 2006 mythic → hat_wizard
- 2007 heirloom → hat_explorer

## chestplate (base 2100)
- 2100 poor → backpack
- 2101 common → backpack
- 2102 uncommon → shield_small
- 2103 rare → shield_a
- 2104 epic → shield_b
- 2105 legendary → shield_b
- 2106 mythic → shield_b
- 2107 heirloom → backpack

## leggings (base 2200)
- 2200 poor → shield_small
- 2201 common → shield_small
- 2202 uncommon → shield_a
- 2203 rare → shield_a
- 2204 epic → shield_b
- 2205 legendary → shield_b
- 2206 mythic → shield_b
- 2207 heirloom → shield_small

## boots (base 2300)
- 2300 poor → shield_small
- 2301 common → shield_small
- 2302 uncommon → shield_small
- 2303 rare → shield_a
- 2304 epic → shield_a
- 2305 legendary → shield_b
- 2306 mythic → shield_b
- 2307 heirloom → shield_small

## Uniques
- 10001 voidreaver_blade → sword_mythic
- 10002 crownfire_aegis → shield_b
- 10003 stormlord_crown → hat_wizard
- 10004 ashen_cleaver → axe_double
- 10005 cinderveil_mantle → backpack
- 10006 thornheart_bow → bow_b
- 10007 verdant_ward → shield_b
- 10008 cryptward_cleaver → axe_viking
- 10009 sepulcher_aegis → shield_a
- 10010 embersovereign_maul → hammer_gold
- 10011 slagveil_mantle → shield_b
- 10012 skyreaver_fang → sword_katana
- 10013 galeweave_cuirass → backpack
- 10014 thundercall_hammer → hammer_gold
- 10015 stormbind_greaves → shield_a
- 10016 sanctum_scepter → wand_necro
- 10017 eldara_crownplate → hat_wizard