# Fonts

## Cormorant Garamond (dialogue.ttf)

- Source: [Cormorant](https://github.com/CatharsisFonts/Cormorant) / Google Fonts
- License: SIL Open Font License 1.1
- Instantiated static Medium (`wght=500`) for Minecraft TTF providers
- Used by `worldofcraft:lore`, `dlg_name`, `dlg_l0`–`dlg_l2` for MMORPG item lore, GUI titles, and dialogue

Rebuild static face: `python scripts/_instantiate_serif.py`
